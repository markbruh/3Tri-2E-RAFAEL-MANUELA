function criaCartao(categoria,pergunta,resposta){
    console.log(categoria,pergunta,resposta)
}
criaCartao("Biologia","Qual a função da mitocondria?","Produzir energia.")